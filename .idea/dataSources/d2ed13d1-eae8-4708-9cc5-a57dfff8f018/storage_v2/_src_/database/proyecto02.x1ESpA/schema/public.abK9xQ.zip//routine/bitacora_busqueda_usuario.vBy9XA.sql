create procedure bitacora_busqueda_usuario(IN id_u integer, IN id_entrenador integer)
    language plpgsql
as
$$
DECLARE
    fecha   DATE;
BEGIN
    SELECT current_date INTO fecha; -- seleccionar la fecha en que se realiza la busqueda
             
    INSERT INTO bitacora_usuario (id_usuario, fecha, instructor)
    VALUES (id_u, fecha, id_entrenador);   
   
END;
$$;

alter procedure bitacora_busqueda_usuario(integer, integer) owner to postgres;

