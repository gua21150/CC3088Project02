create function obtener_nombre(id_user integer, u_rol integer) returns character varying
    language plpgsql
as
$$
DECLARE
    nombre_usuario VARCHAR(50);
BEGIN
    IF u_rol = 5 THEN
        SELECT nickname INTO nombre_usuario FROM usuario WHERE id_usuario = id_user;
    ELSE
        SELECT nombres||' '||apellidos INTO nombre_usuario FROM trabajador WHERE id = id_user AND rol = u_rol;
    END IF;                 
    RETURN (nombre_usuario);
END;
$$;

alter function obtener_nombre(integer, integer) owner to postgres;

