create procedure bitacora_admin(IN id_r integer, IN tipo_r integer, IN descr character varying, IN accion integer)
    language plpgsql
as
$$
DECLARE
    fecha   DATE;
    hora    TIME;
BEGIN
    SELECT current_time::TIME, current_date INTO hora, fecha; -- seleccionar la hora y fecha en que se realiza la accion
    
    IF tipo_r = 5 THEN -- es un usuario       
        INSERT INTO bitacora_admin_usuarios (id_usuario, fecha_accion, hora, descripcion, id_accion)
        VALUES (id_r, fecha, hora, descr, accion);   
    ELSE
        IF  tipo_r >= 1 AND tipo_r < 5 THEN
            INSERT INTO bitacora_admin (id_admin, fecha_accion, hora, descripcion, id_accion)
            VALUES (id_r, fecha, hora, descr, accion);   
        END IF;
    END IF;
END;
$$;

alter procedure bitacora_admin(integer, integer, varchar, integer) owner to postgres;

